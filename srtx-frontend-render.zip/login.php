<?php // src by SRT X CHEATS. Copy right SRT X CHEATS
$pageTitle = 'Login — SRT X CHEATS';
$bodyClass = 'auth-body';
require __DIR__ . '/includes/head.php';
?>

<div id="authChecking" style="text-align:center;padding-top:80px">
    <i class="fas fa-circle-notch fa-spin" style="font-size:26px;color:var(--neon-blue)"></i>
</div>

<div class="auth-shell hidden" id="authShell">
    <div class="auth-brand">
        <div class="logo-img-wrap" style="margin:0 auto">
            <img src="<?= htmlspecialchars(LOGO_URL) ?>" alt="Logo" class="site-logo">
        </div>
        <div class="auth-brand-title">SRT <span class="neon-cyan">X</span> CHEATS</div>
        <div class="auth-brand-sub" style="display:flex;align-items:center;justify-content:center;gap:8px">
            <span>Panels Hub</span>
            <button type="button" class="policy-info-btn" onclick="window.__openPolicyModal('readonly')" title="Terms &amp; Policy" aria-label="View Terms &amp; Policy">!</button>
        </div>
    </div>

    <div class="panel tilt form-pane" id="loginPane">
        <div class="prompt-header"><i class="fas fa-right-to-bracket"></i> ACCOUNT LOGIN</div>
        <div class="field">
            <label><i class="fas fa-envelope"></i> Email</label>
            <input type="email" id="loginEmail" placeholder="you@example.com" autocomplete="username">
        </div>
        <div class="field">
            <label><i class="fas fa-lock"></i> Password</label>
            <input type="password" id="loginPass" placeholder="••••••••" autocomplete="current-password">
        </div>
        <div class="login-verification">
            <div class="login-verification-title"><i class="fas fa-shield-halved"></i> HUMAN VERIFICATION</div>
            <div class="cf-turnstile" id="loginTurnstile"
                 data-sitekey="<?= htmlspecialchars(TURNSTILE_SITE_KEY) ?>"
                 data-theme="dark"
                 data-size="normal"
                 data-callback="onLoginTurnstileSuccess"
                 data-expired-callback="onLoginTurnstileExpired"
                 data-error-callback="onLoginTurnstileError"></div>
            <div id="loginVerificationStatus" class="login-verification-status">Complete the check before continuing.</div>
        </div>
        <button class="btn btn-solid" id="loginBtn" style="margin-bottom:10px"><i class="fas fa-arrow-right-to-bracket"></i> Login</button>

        <div class="auth-divider">or</div>

        <button class="btn btn-google" id="googleBtn" style="margin-bottom:8px"><i class="fab fa-google"></i> Continue with Google</button>
        <button class="btn btn-guest" id="guestBtn" style="margin-bottom:8px"><i class="fas fa-user-secret"></i> Continue as Guest</button>
        <?php $copyrightInline = true; require __DIR__ . '/includes/copyright.php'; ?>

        <div style="display:flex;justify-content:space-between;font-size:12px">
            <a href="/passfor.php" id="forgotLink"><i class="fas fa-key"></i> Forgot Password?</a>
            <a href="#" id="openSignup"><i class="fas fa-user-plus"></i> Register</a>
        </div>
    </div>

    <div class="panel tilt form-pane hidden" id="regPane">
        <div class="prompt-header"><i class="fas fa-user-plus"></i> REGISTER ACCOUNT</div>
        <div class="field">
            <label><i class="fas fa-user"></i> Username</label>
            <input type="text" id="regName" placeholder="Your name" autocomplete="name">
        </div>
        <div class="field">
            <label><i class="fab fa-whatsapp"></i> Number</label>
            <input type="text" id="regPhone" placeholder="98xxxxxxxx" autocomplete="tel" inputmode="tel">
        </div>
        <div class="field">
            <label><i class="fab fa-tiktok"></i> TikTok Name</label>
            <input type="text" id="regTiktokName" placeholder="SRT X CHEATS" autocomplete="off" maxlength="60">
        </div>
        <div class="field">
            <label><i class="fab fa-tiktok"></i> TikTok Username</label>
            <input type="text" id="regTiktokUser" placeholder="@srtxcheats" autocomplete="off" maxlength="25">
        </div>
        <div class="field">
            <label><i class="fas fa-envelope"></i> Email</label>
            <input type="email" id="regEmail" placeholder="you@example.com" autocomplete="username">
        </div>
        <div class="field">
            <label><i class="fas fa-lock"></i> Password</label>
            <input type="password" id="regPass" placeholder="•••••••• (min 6 chars)" autocomplete="new-password">
        </div>
        <div class="field">
            <label><i class="fas fa-lock"></i> Confirm Password</label>
            <input type="password" id="regPassConfirm" placeholder="Repeat your password" autocomplete="new-password">
        </div>
        <button class="btn btn-solid" id="signupBtn" style="margin-bottom:12px"><i class="fas fa-user-check"></i> Create Account</button>
        <div style="text-align:center;font-size:12px">
            <a href="#" id="openLogin"><i class="fas fa-arrow-left"></i> Back to Login</a>
        </div>
    </div>

    <div class="panel" style="text-align:center;border-color:var(--neon-red)">
        <a href="<?= htmlspecialchars(YOUTUBE_GUIDE_URL) ?>" target="_blank" style="color:var(--neon-red);font-weight:700;text-decoration:none;display:flex;align-items:center;justify-content:center;gap:8px">
            <i class="fab fa-youtube" style="font-size:22px"></i>
            <span>Watch: How to buy or add balance <i class="fas fa-coins"></i></span>
        </a>
    </div>
</div>

<script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>
<script>
// src by SRT X CHEATS. Copy right SRT X CHEATS
window.__srtLoginTurnstileToken = '';
window.onLoginTurnstileSuccess = function(token) {
    // src by SRT X CHEATS. Copy right SRT X CHEATS
    window.__srtLoginTurnstileToken = token || '';
    const el = document.getElementById('loginVerificationStatus');
    if (el) { el.textContent = 'Cloudflare check passed — confirming…'; el.classList.remove('error'); }
};
window.onLoginTurnstileExpired = function() {
    // src by SRT X CHEATS. Copy right SRT X CHEATS
    window.__srtLoginTurnstileToken = '';
    const el = document.getElementById('loginVerificationStatus');
    if (el) { el.textContent = 'Verification expired — complete it again.'; el.classList.add('error'); }
};
window.onLoginTurnstileError = function() {
    // src by SRT X CHEATS. Copy right SRT X CHEATS
    window.__srtLoginTurnstileToken = '';
    const el = document.getElementById('loginVerificationStatus');
    if (el) { el.textContent = 'Verification could not load. Refresh and try again.'; el.classList.add('error'); }
};
</script>

<style>
/* src by SRT X CHEATS. Copy right SRT X CHEATS */
body.auth-body{flex-direction:column}
.auth-shell{width:min(400px,100%);max-width:100%}
.login-verification{overflow:hidden}
/* src by SRT X CHEATS. Copy right SRT X CHEATS */

.login-verification{margin:2px 0 12px;padding:12px;border:1px solid rgba(0,220,255,.28);border-radius:14px;background:rgba(8,12,28,.42);text-align:center;box-sizing:border-box;}
.login-verification-title{font-weight:800;font-size:11px;letter-spacing:1px;margin-bottom:8px;}
.login-verification .cf-turnstile{display:flex;justify-content:center;min-height:65px;}
.login-verification-status{font-size:10px;opacity:.7;margin-top:6px;}
/* src by SRT X CHEATS. Copy right SRT X CHEATS */
.login-verification-status.error{opacity:1;}
</style>
<script type="module">
import {
    auth, checkAuthOnce, backendFetch, toast, setButtonLoading, enableTilt,
    // src by SRT X CHEATS. Copy right SRT X CHEATS
    googleProvider, signInWithPopup, signInWithEmailAndPassword,
    createUserWithEmailAndPassword, sendPasswordResetEmail, getAdditionalUserInfo,
} from '/assets/js/app.js?v=20261018-2';

(async () => {
    // src by SRT X CHEATS. Copy right SRT X CHEATS
    const user = await checkAuthOnce();
    if (user) {
        window.location.href = '/dashboard.php';
        return;
    }
    // src by SRT X CHEATS. Copy right SRT X CHEATS
    document.getElementById('authChecking').classList.add('hidden');
    document.getElementById('authShell').classList.remove('hidden');
    enableTilt();
})();

// src by SRT X CHEATS. Copy right SRT X CHEATS
document.getElementById('openSignup').onclick = (e) => {
    e.preventDefault();
    document.getElementById('loginPane').classList.add('hidden');
    document.getElementById('regPane').classList.remove('hidden');
};
// src by SRT X CHEATS. Copy right SRT X CHEATS
document.getElementById('openLogin').onclick = (e) => {
    e.preventDefault();
    document.getElementById('regPane').classList.add('hidden');
    document.getElementById('loginPane').classList.remove('hidden');
};
// src by SRT X CHEATS. Copy right SRT X CHEATS

async function afterAuth(profileFields) {
    try { await backendFetch('/api/user/init', { method: 'POST', body: JSON.stringify(profileFields || {}) }); } catch (e) { console.error(e); }
    try { sessionStorage.setItem('srtx_session_inited', '1'); } catch (e) {}
    window.location.href = '/dashboard.php';
// src by SRT X CHEATS. Copy right SRT X CHEATS
}

async function requireLoginVerification() {
    const token = window.__srtLoginTurnstileToken;
    if (!token) { toast('Complete the human verification first.', 'error'); return false; }
    // src by SRT X CHEATS. Copy right SRT X CHEATS
    const base = String(window.BACKEND_URL || '').trim().replace(/\/+$/, '');
    if (!base) { toast('Backend URL is not configured.', 'error'); return false; }
    try {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 10000);
        // src by SRT X CHEATS. Copy right SRT X CHEATS
        const r = await fetch(base + '/api/security/verify', {
            method: 'POST', mode: 'cors',
            headers: {'Content-Type':'application/json','Accept':'application/json'},
            body: JSON.stringify({ turnstileToken: token }),
            cache: 'no-store', signal: controller.signal
        // src by SRT X CHEATS. Copy right SRT X CHEATS
        });
        clearTimeout(timer);
        const text = await r.text();
        let d = {}; try { d = text ? JSON.parse(text) : {}; } catch (_) {}
        if (!r.ok || d.success !== true) throw new Error(d.error || `Verification failed (HTTP ${r.status}).`);
        // src by SRT X CHEATS. Copy right SRT X CHEATS
        window.__srtLoginTurnstileToken = '';
        const el = document.getElementById('loginVerificationStatus');
        if (el) { el.innerHTML = '<i class="fas fa-circle-check"></i> Human verification confirmed'; el.classList.remove('error'); }
        try { if (window.turnstile && document.getElementById('loginTurnstile')) window.turnstile.reset('#loginTurnstile'); } catch (_) {}
        return true;
    // src by SRT X CHEATS. Copy right SRT X CHEATS
    } catch (e) {
        window.__srtLoginTurnstileToken = '';
        const el = document.getElementById('loginVerificationStatus');
        if (el) { el.textContent = e?.name === 'AbortError' ? 'Security server timeout — try again.' : (e.message || 'Verification failed — try again.'); el.classList.add('error'); }
        try { if (window.turnstile && document.getElementById('loginTurnstile')) window.turnstile.reset('#loginTurnstile'); } catch (_) {}
        // src by SRT X CHEATS. Copy right SRT X CHEATS
        toast(e.message || 'Human verification failed.', 'error');
        return false;
    }
}

// src by SRT X CHEATS. Copy right SRT X CHEATS
document.getElementById('loginBtn').onclick = async () => {
    const email = document.getElementById('loginEmail').value.trim();
    const pass = document.getElementById('loginPass').value;
    if (!email || !pass) return toast('Fill both fields', 'error');
    const btn = document.getElementById('loginBtn');
    // src by SRT X CHEATS. Copy right SRT X CHEATS
    if (!(await requireLoginVerification())) return;
    setButtonLoading(btn, true);
    try {
        await signInWithEmailAndPassword(auth, email, pass);
        await afterAuth();
    // src by SRT X CHEATS. Copy right SRT X CHEATS
    } catch (e) {
        toast(e.message, 'error');
        setButtonLoading(btn, false);
    }
};
// src by SRT X CHEATS. Copy right SRT X CHEATS

document.getElementById('signupBtn').onclick = async () => {
    const name = document.getElementById('regName').value.trim();
    const phone = document.getElementById('regPhone').value.trim();
    const tiktokName = document.getElementById('regTiktokName').value.trim();
    // src by SRT X CHEATS. Copy right SRT X CHEATS
    const tiktokUser = document.getElementById('regTiktokUser').value.trim();
    const email = document.getElementById('regEmail').value.trim();
    const pass = document.getElementById('regPass').value;
    const passConfirm = document.getElementById('regPassConfirm').value;
    if (!name || !phone || !tiktokName || !tiktokUser || !email || !pass || !passConfirm) return toast('Fill all fields', 'error');
    // src by SRT X CHEATS. Copy right SRT X CHEATS
    if (!/^@?[A-Za-z0-9._]{2,24}$/.test(tiktokUser)) return toast('TikTok username: letters, numbers, dots and underscores only (e.g. @srtxcheats)', 'error');
    if (pass.length < 6) return toast('Password must be at least 6 characters', 'error');
    if (pass !== passConfirm) return toast('Passwords do not match', 'error');
    const btn = document.getElementById('signupBtn');
    if (!(await requireLoginVerification())) return;
    // src by SRT X CHEATS. Copy right SRT X CHEATS
    setButtonLoading(btn, true);
    try {
        await createUserWithEmailAndPassword(auth, email, pass);
        await afterAuth({ name, phone, tiktokName, tiktokUser });
    } catch (e) {
        // src by SRT X CHEATS. Copy right SRT X CHEATS
        toast(e.message, 'error');
        setButtonLoading(btn, false);
    }
};

// src by SRT X CHEATS. Copy right SRT X CHEATS
document.getElementById('googleBtn').onclick = async () => {
    if (!(await requireLoginVerification())) return;
    try {
        const result = await signInWithPopup(auth, googleProvider);
        const isNewUser = !!getAdditionalUserInfo(result)?.isNewUser;
        // src by SRT X CHEATS. Copy right SRT X CHEATS
        if (isNewUser) {
            try { await backendFetch('/api/user/init', { method: 'POST' }); } catch (e) { console.error(e); }
            window.location.href = '/profile.php?complete=1';
            return;
        }
        // src by SRT X CHEATS. Copy right SRT X CHEATS
        await afterAuth();
    } catch (e) {
        if (e.code !== 'auth/popup-closed-by-user') toast(e.message, 'error');
    }
};
// src by SRT X CHEATS. Copy right SRT X CHEATS

document.getElementById('guestBtn').onclick = () => {
    window.location.href = '/home.php';
};

</script>

<?php require __DIR__ . '/includes/policy-modal.php'; ?>

</body>
</html>
