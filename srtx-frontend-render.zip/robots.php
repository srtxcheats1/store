<?php
require __DIR__ . '/includes/config.php';
header('Content-Type: text/plain; charset=utf-8');
?>User-agent: *
Allow: /
Disallow: /admin/
Disallow: /login.php
Disallow: /dashboard.php
Disallow: /profile.php
Disallow: /includes/

Sitemap: <?= SITE_URL ?>/sitemap.xml
