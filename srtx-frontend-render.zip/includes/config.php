<?php // src by SRT X CHEATS. Copy right SRT X CHEATS
(function () {
    $f = __DIR__ . '/.env';
    if (!is_readable($f)) return;
    foreach (file($f, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        // src by SRT X CHEATS. Copy right SRT X CHEATS
        $line = trim($line);
        if ($line === '' || $line[0] === '#' || strpos($line, '=') === false) continue;
        [$k, $v] = array_map('trim', explode('=', $line, 2));
        $v = trim($v, "\"'");
        if ($k !== '' && getenv($k) === false) { putenv("$k=$v"); $_ENV[$k] = $v; }
    // src by SRT X CHEATS. Copy right SRT X CHEATS
    }
})();

$env = static fn (string $k, string $d = '') => (($v = getenv($k)) !== false && $v !== '') ? $v : $d;

// src by SRT X CHEATS. Copy right SRT X CHEATS
// ---------------------------------------------------------------------------
// ALL settings come from environment variables (Render dashboard -> Environment,
// or a local includes/.env file for development). Nothing secret/URL-based is
// hard-coded here any more. See .env.example for the full list.
// ---------------------------------------------------------------------------

// Branding / site
define('COPYRIGHT_NAME', $env('COPYRIGHT_NAME', 'SRT X CHEATS'));
define('SITE_NAME', $env('SITE_NAME', 'SRT X CHEATS'));
define('SITE_URL', rtrim($env('SITE_URL'), '/'));            // e.g. https://your-site.onrender.com
define('SITE_ICON', $env('SITE_ICON'));                       // favicon / og:image
define('LOGO_URL', $env('LOGO_URL', $env('SITE_ICON')));      // logo shown on login/loader
define('DEVELOPER_URL', $env('DEVELOPER_URL'));

// Backend API (your other Render service)
define('BACKEND_URL', rtrim($env('BACKEND_URL'), '/'));       // e.g. https://repromax5.onrender.com

// Cloudflare Turnstile (public site key)
define('TURNSTILE_SITE_KEY', $env('TURNSTILE_SITE_KEY'));

// WhatsApp / external links
define('WELCOME_REDIRECT_URL', $env('WELCOME_REDIRECT_URL'));
define('WHATSAPP_TOPUP_NUMBER', $env('WHATSAPP_TOPUP_NUMBER'));
define('WHATSAPP_TOPUP_MESSAGE', $env('WHATSAPP_TOPUP_MESSAGE', 'I am coming from admin panel and I want to get deposit balance and get panel key'));
define('RESELLER_COMMUNITY_URL', $env('RESELLER_COMMUNITY_URL'));
define('TIKTOK_GUIDE_URL', $env('TIKTOK_GUIDE_URL'));
define('YOUTUBE_GUIDE_URL', $env('YOUTUBE_GUIDE_URL'));
define('ESEWA_QR_URL', $env('ESEWA_QR_URL'));

// "All updates" page channels
define('UPDATE_LINK_DRIP', $env('UPDATE_LINK_DRIP'));
define('UPDATE_LINK_HG_1', $env('UPDATE_LINK_HG_1'));
define('UPDATE_LINK_HG_2', $env('UPDATE_LINK_HG_2'));
define('UPDATE_LINK_OTHER', $env('UPDATE_LINK_OTHER'));

// Home banners: comma-separated list of image URLs
define('BANNERS', array_values(array_map(
    static fn ($u) => ['image' => $u],
    array_filter(array_map('trim', explode(',', $env('BANNER_IMAGES'))))
)));

// Firebase web config (Firebase console -> Project settings -> Your apps -> Web app)
define('FIREBASE_CONFIG_JSON', json_encode([
    'apiKey' => $env('FIREBASE_API_KEY'),
    'authDomain' => $env('FIREBASE_AUTH_DOMAIN'),
    'projectId' => $env('FIREBASE_PROJECT_ID'),
    'storageBucket' => $env('FIREBASE_STORAGE_BUCKET'),
    'messagingSenderId' => $env('FIREBASE_MESSAGING_SENDER_ID'),
    'appId' => $env('FIREBASE_APP_ID'),
], JSON_UNESCAPED_SLASHES));

// Log (not crash) if something essential is missing, so Render logs show why login fails
foreach (['BACKEND_URL', 'FIREBASE_API_KEY', 'FIREBASE_AUTH_DOMAIN', 'FIREBASE_PROJECT_ID', 'FIREBASE_APP_ID', 'SITE_URL'] as $__k) {
    if ($env($__k) === '') error_log("[config] Missing required environment variable: $__k");
}
unset($__k);
